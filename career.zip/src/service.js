

const API_URL = "http://localhost:8080/api/";   




// const API_URL = "http://54.85.206.146:9467/api/";








export default API_URL;
